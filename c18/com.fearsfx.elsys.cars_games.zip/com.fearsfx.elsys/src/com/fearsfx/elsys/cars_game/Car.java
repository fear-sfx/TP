package com.fearsfx.elsys.cars_game;

public class Car extends Vehicle{
	Car(){
		x=0.0; y=0.0;
	}
	public void setLoad(int val) {
		if((this.load + val) < 1000){
			this.load += val;
			System.out.println("Locked and loaded .. !!");
		}else{
			System.out.println("LOL, bro .. take it easier ");
		}
	}

}
