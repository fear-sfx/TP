package com.fearsfx.elsys.green_belt;

public class Label extends Widget {
	Label(double x, double y, String text){
		this.x = x;
		this.y = y;
		this.text = text;
	}
}
