package com.fearsfx.elsys.green_belt;

interface IClickable {
	public String click();
}
