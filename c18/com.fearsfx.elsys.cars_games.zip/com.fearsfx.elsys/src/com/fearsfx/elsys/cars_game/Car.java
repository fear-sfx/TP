package com.fearsfx.elsys.cars_game;

public class Car extends Vehicle {
	Car(){
		x=0.0; y=0.0;
	}

}
