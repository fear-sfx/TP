package com.fearsfx.elsys.cars_game;

public class Truck extends Vehicle{
	Truck(){
		x=0.0; y=0.0;
	}
}
