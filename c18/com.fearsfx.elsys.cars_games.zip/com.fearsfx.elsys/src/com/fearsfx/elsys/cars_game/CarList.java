package com.fearsfx.elsys.cars_game;

import java.util.ArrayList;
import java.util.List;

public class CarList {
	List<Vehicle> carList = new ArrayList<Vehicle>();
	
	CarList(){
		for(int i = 0; i<10; i++){
			if(i<5){
				Car car = new Car();
				carList.add(car);
			}else{
				Truck truck = new Truck();
				carList.add(truck);
			}
			carList.get(i).setNum(i);
		}
	}
	public void print(){
		for(int i = 0; i<10; i++){
			carList.get(i).print();
		}
	}
	public void move(int num, double x, double y){
		carList.get(num).setX(x);
		carList.get(num).setY(y);
	}
	public Vehicle getVehicle(int num){
		return carList.get(num);
	}
}
