package com.fearsfx.elsys.cars_game;

public class Truck extends Vehicle{
	Truck(){
		x=0.0; y=0.0;
	}
	public void setLoad(int val) {
		if((this.load + val) < 20000){
			this.load += val;
			System.out.println("Locked and loaded .. !!");
		}else{
			System.out.println("LOL, bro .. take it easier ");
		}
	}

}
