package com.fearsfx.elsys.cars_game;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		
		CarList list = new CarList();
		Scanner reader = new Scanner(System.in);
				
//		list.print();
		
		System.out.println("Enter num : ");

		int num = reader.nextInt();
		double x = reader.nextDouble();
		double y = reader.nextDouble();
		
		list.move(num, x, y);
		list.print();
		
//		list.move(9, 4, 6);
		System.out.println(list.getVehicle(9).getX());
		
		list.getVehicle(9).setLoad(5000);
		System.out.println(list.getVehicle(9).getLoad());
		
		list.getVehicle(3).setLoad(5000);
		System.out.println(list.getVehicle(3).getLoad());
		
	}

}
