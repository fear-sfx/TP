package com.fearsfx.elsys.cars_game;

public class Vehicle implements Loadable {
	double x, y;
	int num, load;
		
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public void print(){
		System.out.println("(x, y) = (" + this.x + ", " + this.y + ")");
		System.out.println("Num : " + this.num);
	}
	public void move(double x, double y){
		this.x = x;
		this.y = y;
	}
	public int getLoad() {
		return this.load;
	}
	public void setLoad(int val) {
		this.load += val;		
	}
}

interface Loadable{
	public int getLoad();
	public void setLoad(int val);
	
}